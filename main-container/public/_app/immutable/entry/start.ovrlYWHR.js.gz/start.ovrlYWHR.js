import{l as o,a as r}from"../chunks/l0l0N_xL.js";export{o as load_css,r as start};
