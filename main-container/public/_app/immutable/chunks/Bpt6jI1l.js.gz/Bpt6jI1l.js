const t="https://localhost:5174";export{t as P};
